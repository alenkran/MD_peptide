get_bash_str = lambda dir, filename: f'''#!/bin/bash
ml chemistry gromacs
cd {dir}

{{ echo "1"; echo "3"; echo "0"; }} | gmx pdb2gmx -f {filename}.pdb -o {filename}.gro -ter -water tip3p
gmx editconf -f {filename}.gro -o {filename}_newbox.gro -c -d 1.0 -bt dodecahedron
gmx solvate -cp {filename}_newbox.gro -cs spc216.gro -o {filename}_solv.gro -p topol.top
gmx grompp -f ../ions.mdp -c {filename}_solv.gro -p topol.top -o ions.tpr
echo "13" | gmx genion -s ions.tpr -o {filename}_solv_ions.gro -p topol.top -pname NA -nname CL -neutral
gmx grompp -f ../minim.mdp -c {filename}_solv_ions.gro -p topol.top -o em.tpr
gmx mdrun -v -deffnm em
gmx grompp -f ../nvt.mdp -c em.gro -r em.gro -p topol.top -o nvt.tpr
gmx mdrun -deffnm nvt
gmx grompp -f ../npt.mdp -c nvt.gro -r nvt.gro -t nvt.cpt -p topol.top -o npt.tpr
gmx mdrun -deffnm npt
gmx grompp -f ../md.mdp -c npt.gro -t npt.cpt -p topol.top -o md_300.tpr'''

sbatch_cpu_top = lambda i: f'''#!/bin/bash
#SBATCH --job-name=md_{i}
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=bvbell@stanford.edu
#SBATCH --qos=normal
#SBATCH --time=2-00:00:00
#SBATCH -p normal,possu
#SBATCH --ntasks=16
#SBATCH --nodes=1
#SBATCH --mem-per-cpu=8000
#SBATCH --output=cpu_{i}.out

ml chemistry gromacs

'''

sbatch_gpu_top = lambda i: f'''#!/bin/bash
#SBATCH --job-name=md_{i}
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=bvbell@stanford.edu
#SBATCH --time=7-00:00:00
#SBATCH --ntasks=1
#SBATCH -p bioe,possu
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-gpu=2
#SBATCH --output=gpu_{i}.out

ml chemistry gromacs

'''
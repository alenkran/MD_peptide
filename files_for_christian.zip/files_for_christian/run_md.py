import sys
from pathlib import Path
import pickle
import shutil
import subprocess
import numpy as np

import bash_strings

n_wt = 100
n_single = 5
n_double = 1
pdb_dir = Path('/scratch/users/bvbell/thioether/processed_thioether_conformers/double')
n_arrays = 50

def create_file_list(input_dir=pdb_dir):
    result = []
    wt_seq = [f'{n}A_C' for n in range(9, 13)]
    for filename in input_dir.glob('*.pkl'):
        with open(filename, 'rb') as f:
            d = pickle.load(f)
        
        if filename.stem in wt_seq:
            if len(d) < n_wt:
                result += [(str(filename), f'{filename.stem}_{i}.pdb') for i in range(len(d))]
            else:
                result += [(str(filename), f'{filename.stem}_{i}.pdb') for i in range(n_wt)]
        else:
            result += [(str(filename), f'{filename.stem}_{i}.pdb') for i in range(n_single)]
    return result

def copy_files(target_dir):
    shutil.copy('specbond.dat', f'{target_dir}/specbond.dat')
    shutil.copytree('oplsaa.ff', f'{target_dir}/oplsaa.ff')
    return

def prepare_md_input(pkl_file, pdb_file):
    with open(pkl_file, 'rb') as f:
        pdb_str = pickle.load(f)[pdb_file]['pdb']
    
    new_dir = Path(pdb_file[:-4])
    new_dir_pdb = new_dir / pdb_file
    if not new_dir.is_dir():
        new_dir.mkdir()
        new_dir_pdb.write_text(pdb_str)
    cmd = bash_strings.get_bash_str(new_dir, new_dir_pdb.stem)
    new_dir_cmd = new_dir / 'prepare_md.sh'
    new_dir_cmd.write_text(cmd)
    copy_files(new_dir)
    subprocess.run(['bash', str(new_dir_cmd)])
    return

def write_cpu_sbatch(list_of_dirs, i, sbatch_dir='sbatch'):
    if not Path(sbatch_dir).exists():
        Path(sbatch_dir).mkdir()

    sbatch_str = bash_strings.sbatch_cpu_top(i)
    for folder in list_of_dirs:
        sbatch_str += f'cd ../{folder}\n'
        sbatch_str += f'gmx mdrun -deffnm md_300\n'
        sbatch_str += f'cd ../{sbatch_dir}\n\n'
    with open(f'{sbatch_dir}/cpu_{i}.sbatch', 'w') as f:
        f.write(sbatch_str)
    return

def write_gpu_sbatch(list_of_dirs, i, sbatch_dir='sbatch'):
    if not Path(sbatch_dir).exists():
        Path(sbatch_dir).mkdir()

    sbatch_str = bash_strings.sbatch_gpu_top(i)
    for folder in list_of_dirs:
        sbatch_str += f'cd ../{folder}\n'
        sbatch_str += f'gmx_cuda mdrun -deffnm md_300\n'
        sbatch_str += f'cd ../{sbatch_dir}\n\n'
    with open(f'{sbatch_dir}/gpu_{i}.sbatch', 'w') as f:
        f.write(sbatch_str)
    return

def check_md_tpr(md_dir=None):
    if md_dir is None:
        exclude = {'sbatch', 'oplsaa.ff', '__pycache__'}
        missing_tprs = []
        for child in Path.cwd().iterdir():
            dir_name = child.name
            if child.is_dir() and dir_name not in exclude:
                if not (child / 'md_300.tpr').is_file():
                    missing_tprs.append(dir_name)
        
        if len(missing_tprs) != 0:
            print(f'Missing tpr files:\n{missing_tprs}')
        else:
            print('No missing tpr files')
    else:
        tpr_file = md_dir / 'md_300.tpr'
        if tpr_file.is_file():
            print(f'{md_dir} contains a tpr file')
        else:
            print(f'{md_dir} does not contain a tpr file')

def get_completed_list():
    result = []
    excluded = {'sbatch', 'oplsaa.ff', '__pycache__'}
    for child in Path.cwd().iterdir():
        if child.name not in excluded and child.is_dir():
            log = child / 'md_300.log'
            if log.is_file():
                log = log.read_text().split('\n')[-3]
                if log.startswith('Finished'):
                    result.append(child.name)
    return result

def left2do():
    result = []
    excluded = {'sbatch', 'oplsaa.ff', '__pycache__'}
    completed = set(get_completed_list())
    for child in Path.cwd().iterdir():
        if child.name not in excluded and child.name not in completed and child.is_dir():
            result.append(child.name)
    return result

def main():
    completed = set(get_completed_list())
    with open('merck.list') as f:
        left = [seq for seq in f.read().split('\n') if seq not in completed]
    left = sorted(left)[::-1]
    write_gpu_sbatch(left[:25], 0)
    write_gpu_sbatch(left[25:50], 1)
    write_gpu_sbatch(left[50:75], 2)
    write_gpu_sbatch(left[75:100], 3)

if __name__ == "__main__":
    main()
